#!/bin/bash

sudo service nginx status
sudo service nginx stop