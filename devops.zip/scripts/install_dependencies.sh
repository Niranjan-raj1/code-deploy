#!/bin/bash

sudo yum update -y
sudo ls -R
sudo amazon-linux-extras install nginx1 -y
sudo yum install java -y
sudo rm -rf /usr/share/nginx/html/index.html
sudo mkdir -p /usr/share/nginx/html/demo/demo1/demo2/demo3